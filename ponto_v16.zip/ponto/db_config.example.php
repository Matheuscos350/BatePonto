<?php
// Copie este arquivo para db_config.php e preencha para usar MySQL/MariaDB.
// Sem db_config.php o sistema usa SQLite (arquivo data/ponto.sqlite).
// Também dá para usar variáveis de ambiente: PONTO_DB_DRIVER, PONTO_DB_HOST, PONTO_DB_PORT, PONTO_DB_NAME, PONTO_DB_USER, PONTO_DB_PASS.
return [
    'driver' => 'mysql',          // 'mysql' (MySQL ou MariaDB) ou 'sqlite'
    'host'   => '127.0.0.1',      // em hospedagem compartilhada costuma ser 'localhost'
    'port'   => 3306,
    'name'   => 'ponto',          // nome do banco (crie antes no painel da hospedagem, com utf8mb4)
    'user'   => 'usuario_do_banco',
    'pass'   => 'senha_do_banco',
    // 'socket' => '/var/run/mysqld/mysqld.sock',   // só se a hospedagem exigir socket
];
