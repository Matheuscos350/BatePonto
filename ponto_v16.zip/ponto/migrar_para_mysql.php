<?php
declare(strict_types=1);
/**
 * Copia TODOS os dados do SQLite (data/ponto.sqlite) para o MySQL/MariaDB configurado em db_config.php.
 * Só roda pelo terminal:   php migrar_para_mysql.php            (banco MySQL precisa estar vazio)
 *                          php migrar_para_mysql.php --force    (apaga o conteúdo do MySQL antes)
 * As fotos e notas (pasta uploads/) não mudam de lugar. O arquivo SQLite não é alterado nem apagado.
 */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
define('PONTO_NO_SEED', true);
require __DIR__ . '/config.php';

if (db_driver() !== 'mysql') { fwrite(STDERR, "Configure o MySQL em db_config.php (driver = mysql) antes. Veja db_config.example.php.\n"); exit(1); }
if (!is_file(DB_FILE)) { fwrite(STDERR, "Arquivo SQLite não encontrado: " . DB_FILE . "\n"); exit(1); }
$force = in_array('--force', $argv, true);

$src = new PDO('sqlite:' . DB_FILE);
$src->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$src->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
$dst = db();   // cria as tabelas no MySQL

$tables = ['users', 'sites', 'punches', 'tickets', 'abonos', 'punch_audit', 'expenses', 'expense_files'];
$have = (int)$dst->query('SELECT COUNT(*) FROM users')->fetchColumn();
if ($have > 0 && !$force) { fwrite(STDERR, "O MySQL já tem dados ($have usuário(s)). Use --force para apagar e copiar de novo.\n"); exit(1); }

$dst->exec('SET FOREIGN_KEY_CHECKS = 0');
if ($force) foreach (array_reverse($tables) as $t) $dst->exec("DELETE FROM `$t`");
$dst->beginTransaction();
try {
    foreach ($tables as $t) {
        $exists = $src->query("SELECT name FROM sqlite_master WHERE type='table' AND name='$t'")->fetchColumn();
        if (!$exists) { echo str_pad($t, 14) . " (não existe no SQLite)\n"; continue; }
        $scols = array_column($src->query("PRAGMA table_info($t)")->fetchAll(), 'name');
        $dcols = db_columns($dst, $t);
        $cols = array_values(array_intersect($scols, $dcols));
        $ins = $dst->prepare("INSERT INTO `$t` (`" . implode('`,`', $cols) . "`) VALUES (" . implode(',', array_fill(0, count($cols), '?')) . ")");
        $n = 0;
        foreach ($src->query("SELECT `" . implode('`,`', $cols) . "` FROM `$t` ORDER BY id") as $row) {
            foreach ($row as $k => $v) if ($v === '' && in_array($k, ['cpf', 'email'], true)) $row[$k] = null;   // UNIQUE do MySQL não aceita '' repetido
            $ins->execute(array_values($row));
            $n++;
        }
        echo str_pad($t, 14) . " $n registro(s)\n";
    }
    $dst->commit();
} catch (Throwable $e) {
    $dst->rollBack();
    fwrite(STDERR, "ERRO: " . $e->getMessage() . "\nNada foi gravado no MySQL.\n");
    exit(1);
}
$dst->exec('SET FOREIGN_KEY_CHECKS = 1');
echo "\nPronto! O sistema já usa o MySQL. O arquivo SQLite continua em data/ como backup.\n";
